﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] array1 = { 5, 2, 8, 1, 9 };
        int[] array2 = { 3, 7, 4 };

        SortAscending(array1);
        SortDescending(array2);
        int[] m = MergeArrays(array1, array2);

        Console.WriteLine($"По возрастанию: {string.Join(", ", array1)}");
        Console.WriteLine($"По убыванию: {string.Join(", ", array2)}");
        Console.WriteLine($"Объединенный массив: {string.Join(", ", m)}");

        Console.WriteLine(DifferenceWith123(150));
    }

    // 1.
    static void SortAscending(int[] arr)
    {
        Array.Sort(arr);
    }

    // 2.
    static void SortDescending(int[] arr)
    {
        Array.Sort(arr);
        Array.Reverse(arr);
    }

    // 3.
    static int[] MergeArrays(int[] arr1, int[] arr2)
    {
        return arr1.Concat(arr2).ToArray();
    }

    // Задание 2
    static int DifferenceWith123(int n)
    {
        int diff = Math.Abs(n - 123);

        if (n > 123)
            return diff * 3;
        else
            return diff;
    }

}