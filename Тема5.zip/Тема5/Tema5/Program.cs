﻿using System;

class Program
{
    static void Main()
    {

        string a = "Hello";
        string b = "Hello";
        string c = "hello";

        // 1. Compare()
        //Console.WriteLine("Compare:");
        //Console.WriteLine(string.Compare(a, b));
        //Console.WriteLine(string.Compare(a, c));
        //Console.WriteLine(string.Compare(a, c, true));

        // 2. CompareOrdinal()
        //Console.WriteLine("CompareOrdinal:");
        //Console.WriteLine(string.CompareOrdinal(a, b));
        //Console.WriteLine(string.CompareOrdinal(a, c));

        //// 3. Equals()
        //Console.WriteLine("Equals:");
        //Console.WriteLine(a.Equals(b));
        //Console.WriteLine(a.Equals(c));

        //// 4. Операторы == и !=
        //Console.WriteLine("== и !=");
        //Console.WriteLine(a == b);
        //Console.WriteLine(a == c);
        //Console.WriteLine(a != c);

        //// 5. IndexOf()
        //Console.WriteLine("IndexOf:");
        //string s = "Hello, World!";
        //Console.WriteLine(s.IndexOf("World"));
        //Console.WriteLine(s.IndexOf("xyz"));

        //// 6. Contains()
        //Console.WriteLine("Contains:");
        //Console.WriteLine(s.Contains("World"));
        //Console.WriteLine(s.Contains("xyz"));

        //Console.ReadKey();
    }
}
