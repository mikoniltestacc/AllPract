﻿using System;
using System.Globalization;

class Program
{
    static void Main()
    {
        //1. Parse
        string heroLevel = "42";
        int level = int.Parse(heroLevel);
        Console.WriteLine($"Герой достиг {level} уровня!");

        //2. TryParse
        string chestGold = "много";
        if (int.TryParse(chestGold, out int gold))
            Console.WriteLine($"В сундуке {gold} золота.");
        else
            Console.WriteLine("Сундук оказался пустым.");

        //3. ParseExact
        string dateOfBirth = "01012000";
        DateTime birthday = DateTime.ParseExact(dateOfBirth, "ddMMyyyy", CultureInfo.InvariantCulture);
        Console.WriteLine($"День рождения: {birthday:dd MMMM yyyy}");

        //4. TryParseExact
        string code = "123-45";
        if (int.TryParse(code.Replace("-", ""), out int secretCode))
        {
            Console.WriteLine($"Секретный код принят: {secretCode}");
        }
        else
        {
            Console.WriteLine("Код неверного формата. Охрана вызвана.");
        }
    }
}