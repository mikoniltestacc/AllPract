﻿using System;

namespace SimpleExceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. DivideByZeroException (деление на ноль)
            try
            {
                int a = 10;
                int b = 0;
                int result = a / b;
                Console.WriteLine(result);
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("1. DivideByZeroException (деление на ноль)");
            }

            // 2. ArgumentOutOfRangeException (значение вне диапазона)
            //try
            //{
            //    int age = -5;
            //    if (age < 0)
            //        throw new ArgumentOutOfRangeException(nameof(age), "Возраст не может быть отрицательным");
            //}
            //catch (ArgumentOutOfRangeException)
            //{
            //    Console.WriteLine("2. ArgumentOutOfRangeException (значение вне диапазона)");
            //}

            //// 3. ArgumentException (некорректное значение параметра)
            //try
            //{
            //    string name = "";
            //    if (string.IsNullOrEmpty(name))
            //        throw new ArgumentException("Имя не может быть пустым", nameof(name));
            //}
            //catch (ArgumentException)
            //{
            //    Console.WriteLine("3. ArgumentException (некорректный аргумент)");
            //}

            //// 4. IndexOutOfRangeException (индекс вне границ массива)
            //try
            //{
            //    int[] numbers = { 1, 2, 3 };
            //    int value = numbers[5];
            //    Console.WriteLine(value);
            //}
            //catch (IndexOutOfRangeException)
            //{
            //    Console.WriteLine("4. IndexOutOfRangeException (индекс вне границ)");
            //}

            //// 5. InvalidCastException (недопустимое преобразование типов)
            //try
            //{
            //    object obj = "Это строка";
            //    int number = (int)obj;
            //    Console.WriteLine(number);
            //}
            //catch (InvalidCastException)
            //{
            //    Console.WriteLine("5. InvalidCastException (недопустимое преобразование)");
            //}

            //// 6. NullReferenceException (обращение к null)
            //try
            //{
            //    string text = null;
            //    int length = text.Length;
            //    Console.WriteLine(length);
            //}
            //catch (NullReferenceException)
            //{
            //    Console.WriteLine("6. NullReferenceException (обращение к null)");
            //}

            //Console.WriteLine("\nПрограмма завершилась без падения.");
            //Console.ReadKey();
        }
    }
}