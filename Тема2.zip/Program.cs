﻿using System;

namespace MyHomework
{
    class Calculator
    {
        public int Add(int x, int y)
        {
            return x + y;
        }

        private double Dev(int x, int y)
        {
            return (double)x / y;
        }

        public double DoDev(int x, int y)
        {
            return Dev(x, y);
        }
    }

    class User
    {
        private int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }

        public User(int id, string name, string email, int age)
        {
            Id = id;
            Name = name;
            Email = email;
            Age = age;
        }

        public void ShowInfo()
        {
            Console.WriteLine("ID: " + Id);
            Console.WriteLine("Имя: " + Name);
            Console.WriteLine("Почта: " + Email);
            Console.WriteLine("Возраст: " + Age);
        }
    }   
}