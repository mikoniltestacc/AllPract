﻿using System;

namespace ClassLibrary1
{
    public class MyMethods
    {
        public void PrintHello()
        {
            Console.WriteLine("Привет из библиотеки!");
        }

        public void PrintSum(int a, int b)
        {
            Console.WriteLine("Сумма: " + (a + b));
        }

        public int Multiply(int a, int b)
        {
            return a * b;
        }

        public double Divide(double a, double b)
        {
            return a / b;
        }

        public string GetGreeting(string name)
        {
            return "Привет, " + name;
        }
    }
}