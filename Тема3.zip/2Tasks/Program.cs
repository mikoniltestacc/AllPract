﻿using System;

namespace MyHomework
{
    class Calculator
    {
        public int Add(int x, int y)
        {
            return x + y;
        }

        private double Dev(int x, int y)
        {
            return (double)x / y;
        }

        public double DoDev(int x, int y)
        {
            return Dev(x, y);
        }
    }

    class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Age { get; set; }

        public User(int id, string name, string email, int age)
        {
            Id = id;
            Name = name;
            Email = email;
            Age = age;
        }

        public void ShowInfo()
        {
            Console.WriteLine("ID: " + Id);
            Console.WriteLine("Имя: " + Name);
            Console.WriteLine("Почта: " + Email);
            Console.WriteLine("Возраст: " + Age);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Задание 1");
            Calculator myCalc = new Calculator();

            int sum = myCalc.Add(10, 5);
            Console.WriteLine("Сумма: " + sum);

            double result = myCalc.DoDev(20, 4);
            Console.WriteLine("Частное: " + result);

            Console.WriteLine();
            Console.WriteLine("Задание 2");

            User user1 = new User(1, "Вася", "vasya@mail.ru", 15);
            user1.ShowInfo();
            Console.ReadKey();
        }
    }
}